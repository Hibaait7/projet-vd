from django.urls import path
from . import views

urlpatterns = [
    path('', views.UploadFileView.as_view(), name='upload'),
    path('analyze/', views.AnalyzeView.as_view(), name='analyze'),
    path('visualization/', views.VisualizationView.as_view(), name='visualization'),
    path('get-plot/', views.PlotView.as_view(), name='get_plot'),
]