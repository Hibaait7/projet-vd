# Importation des bibliothèques nécessaires
from django.shortcuts import render  # Pour rendre les templates HTML
from django.views import View  # Pour utiliser les vues basées sur les classes
import pandas as pd  # Pour manipuler les données tabulaires
import matplotlib.pyplot as plt  # Pour créer des visualisations
import json  # Pour travailler avec des données au format JSON
from django.http import JsonResponse, HttpResponse  # Pour envoyer des réponses HTTP ou JSON
import io  # Pour manipuler les données en mémoire

# Variable globale pour stocker le DataFrame courant
current_df = None

# Changer le backend de Matplotlib pour générer les graphiques sans interface graphique
plt.switch_backend('Agg')

# Classe pour gérer l'importation des fichiers
class UploadFileView(View):
    def get(self, request):
        return render(request, 'data_analysis/upload.html')

    def post(self, request):
        global current_df
        file = request.FILES.get('file')
        if file:
            if not file.name.endswith('.csv'):
                return render(request, 'data_analysis/upload.html', {'error': 'Please upload only CSV files'})

            current_df = pd.read_csv(file)
            context = {
                'columns': list(current_df.columns),
                'statistics': current_df.describe().to_dict(),
                'data_sample': current_df.head().to_html(classes='table table-striped')
            }
            return render(request, 'data_analysis/analysis.html', context)
        return render(request, 'data_analysis/upload.html')

# Classe pour gérer les analyses sur les données
class AnalyzeView(View):
    def post(self, request):
        global current_df  # Accéder à la variable globale
        if current_df is None:
            # Si aucune donnée n'est chargée, retourner une erreur
            return JsonResponse({'error': 'No data loaded'})
        
        # Charger les données envoyées par la requête
        data = json.loads(request.body)
        
        # Si un index de ligne est spécifié
        if 'row_index' in data:
            try:
                row_index = int(data['row_index'])
                if 0 <= row_index < len(current_df):  # Vérifier si l'index est valide
                    row_data = current_df.iloc[row_index].to_dict()  # Extraire les données de la ligne
                    return JsonResponse({'type': 'row', 'data': row_data})
            except:
                return JsonResponse({'error': 'Invalid row index'})
        
        # Si un nom de colonne est spécifié
        if 'column_name' in data:
            column_name = data['column_name']
            if column_name in current_df.columns:  # Vérifier si la colonne existe
                column_data = current_df[column_name].tolist()  # Extraire les données de la colonne
                stats = current_df[column_name].describe().to_dict() if pd.api.types.is_numeric_dtype(current_df[column_name]) else {}
                return JsonResponse({'type': 'column', 'data': column_data, 'stats': stats})
        
        return JsonResponse({'error': 'Invalid request'})

# Fonction pour convertir un graphique en une chaîne encodée en base64
def get_plot_as_base64():
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    plt.close()  # Effacer le graphique actuel
    return base64.b64encode(image_png).decode('utf-8')

# Classe pour gérer la visualisation des données
class VisualizationView(View):
    def get(self, request):
        global current_df
        if current_df is None:
            return render(request, 'data_analysis/upload.html')  # Rediriger vers la page d'upload si aucune donnée n'est chargée
        
        context = {
            'columns': list(current_df.columns)  # Passer les colonnes au template
        }
        return render(request, 'data_analysis/visualization.html', context)

    def post(self, request):
        global current_df
        if current_df is None:
            return JsonResponse({'error': 'No data loaded'})
        
        data = json.loads(request.body)  # Charger les données envoyées par l'utilisateur
        plot_type = data.get('plot_type', 'scatter')  # Type de graphique par défaut : scatter
        x_axis = data.get('x_axis')  # Axe des abscisses
        y_axis = data.get('y_axis')  # Axe des ordonnées

        try:
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # Générer différents types de graphiques en fonction de la requête
            if plot_type == 'scatter':
                ax.scatter(current_df[x_axis], current_df[y_axis])
                ax.set_xlabel(x_axis)
                ax.set_ylabel(y_axis)
                ax.set_title(f'{y_axis} vs {x_axis}')
            elif plot_type == 'line':
                ax.plot(current_df[x_axis], current_df[y_axis])
                ax.set_xlabel(x_axis)
                ax.set_ylabel(y_axis)
                ax.set_title(f'{y_axis} over {x_axis}')
            elif plot_type == 'bar':
                ax.bar(current_df[x_axis], current_df[y_axis])
                ax.set_xlabel(x_axis)
                ax.set_ylabel(y_axis)
                plt.xticks(rotation=45)
                ax.set_title(f'{y_axis} by {x_axis}')
            elif plot_type == 'histogram':
                ax.hist(current_df[x_axis], bins=30)
                ax.set_xlabel(x_axis)
                ax.set_ylabel('Frequency')
                ax.set_title(f'Distribution of {x_axis}')
            else:  # Box plot
                ax.boxplot(current_df[y_axis])
                ax.set_ylabel(y_axis)
                ax.set_title(f'Box Plot of {y_axis}')
            
            plt.tight_layout()

            # Convertir le graphique en image PNG
            buf = io.BytesIO()
            fig.savefig(buf, format='png', bbox_inches='tight', dpi=100)
            plt.close(fig)
            buf.seek(0)
            return HttpResponse(buf.getvalue(), content_type='image/png')
        
        except Exception as e:
            return JsonResponse({'error': str(e)})

# Classe pour afficher un graphique simple
class PlotView(View):
    def get(self, request):
        global current_df
        if current_df is None:
            return HttpResponse('No data loaded', status=400)
        
        # Créer un graphique scatter par défaut
        fig, ax = plt.subplots(figsize=(10, 6))
        numeric_cols = current_df.select_dtypes(include=['float64', 'int64']).columns
        
        if len(numeric_cols) >= 2:
            ax.scatter(current_df[numeric_cols[0]], current_df[numeric_cols[1]])
            ax.set_xlabel(numeric_cols[0])
            ax.set_ylabel(numeric_cols[1])
            ax.set_title(f'{numeric_cols[1]} vs {numeric_cols[0]}')
        
        plt.tight_layout()

        # Convertir le graphique en image PNG
        buf = io.BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        plt.close(fig)
        buf.seek(0)
        return HttpResponse(buf.getvalue(), content_type='image/png')
